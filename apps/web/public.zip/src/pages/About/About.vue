<template>
  <div id="pagetitle">
    <h1>Baimo and Collaborators</h1>
    <h2>About</h2>
  </div>  
  <h3>Hello, This My About</h3>
</template>