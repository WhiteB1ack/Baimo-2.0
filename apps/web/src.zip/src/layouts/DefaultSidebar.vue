<script setup lang="ts">
import { projects } from '../data/projects'

const groups = ['GLSL', 'Three.js', 'Blender', 'ASCII']
</script>

<template>
  <aside id="leftsplit-left">

    <!-- Sort -->
    <p>
      Sort by :
      <a href="#">Author</a> |
      <a href="#">Date</a> |
      <a href="#">Name</a> |
      <a href="#">Type</a>
    </p>

    <p>
      <RouterLink to="/projects">
        &lt; project thumbnails
      </RouterLink>
    </p>

    <hr>

    <section
      v-for="group in groups"
      :key="group"
    >
      <h3>{{ group }}</h3>

      <RouterLink
        v-for="project in projects.filter(
          project => project.category === group
        )"
        :key="project.path"
        :to="project.path"
      >
        {{ project.title }}
      </RouterLink>
    </section>

  </aside>
</template>