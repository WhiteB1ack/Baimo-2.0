<script setup lang="ts">
import SiteHeader from '../components/SiteHeader.vue';
import SiteFooter from '../components/SiteFooter.vue';
import DefaultSidebar from './DefaultSidebar.vue';
</script>

<template>
  <div id="container">
    <SiteHeader/>

    <main id="main">
      <DefaultSidebar />
      <RouterView />
    </main>

    <SiteFooter/>
  </div>
</template>