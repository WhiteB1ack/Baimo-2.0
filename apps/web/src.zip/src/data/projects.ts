// data/projects.ts

export interface Project {
  title: string
  category: string
  path: string
}

export const projects = [
  {
    title: 'Phase Study I',
    category: 'GLSL',
    path: '/projects/shader/shaping-function'
  },
  {
    title: 'Shapes Study I',
    category: 'GLSL',
    path: '/projects/shader/shapes'
  },
  {
    title: 'AAAAAA',
    category: 'Three.js',
    path: '/projects/three/aaaaaa'
  },
  {
    title: 'Blender Flag I',
    category: 'Blender',
    path: '/projects/blender/blender-flag'
  }
]