import { createRouter, createWebHistory } from "vue-router"; 
import Home from "../pages/Home/Home.vue";
import ShapingFunction from '../pages/Projects/Shader/theBookofShader/01_shapingFunction/01_shapingFunction.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      component: Home,
    },
    {
      path: '/projects/shader/shaping-function',
      component: ShapingFunction,
    }
  //   {
  //     path: '/about',
  //     component: About,
  //   },
  //   {
  //     path: '/projects',
  //     component: Projects
  //   },
  //   {
  //     path: '/lab',
  //     component: Lab
  //   }    
  ]
})

export default router