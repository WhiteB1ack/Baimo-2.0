<template>
  <div class="page-title">
    <h1>Baimo and Collaborators</h1>
    <p>projects</p>
  </div>
</template>